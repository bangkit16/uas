<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "pentium2";

$connect = mysqli_connect($hostname, $username, $password, $database);
